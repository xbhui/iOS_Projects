import UIKit

class ViewController: UIViewController {
    @IBOutlet var stampButtons: [UIButton]!
    private var selectedColor: UIColor = .black

    @IBAction func stampTapped(_ sender: UIButton) {
        guard let stampColor = sender.backgroundColor else {
            return
        }

        self.selectedColor = stampColor
        self.updateButtonColors(selectedButton: sender)
    }

    private func updateButtonColors(selectedButton: UIButton) {
        self.stampButtons.forEach { $0.alpha = 1.0 }
        selectedButton.alpha = 0.5
    }
}
