//
//  PhotoDetail.swift
//  SharkFeed
//
//  Created by gauss on 6/15/19.
//  Copyright © 2019 xiubao. All rights reserved.
//

import UIKit

struct PhotosDetail {

    var photoid: String!
    var imgURLt: String!
    var imgURLc: String!
    var imgURLo: String!
    var photoTitle: String!
    var photoDescription: String!
    var photoPageurl: String!
}
