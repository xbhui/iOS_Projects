//
//  ViewController.swift
//  SharkFeed
//
//  Created by gauss on 6/14/19.
//  Copyright © 2019 xiubao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.gray
    }
}
